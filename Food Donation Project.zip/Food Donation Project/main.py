from tkinter  import *
from tkinter import messagebox


import pymongo
from pymongo import collection

root=Tk()
root.geometry("1100x630+300+190")
root.resizable(False,False)
root.title("Feed the Need")
root.configure(bg="#adacb1")

def Donate(A1,B2,C3,D4,E5):
    background="#06283D"
    framebg="#EDEDED"
    framefg="#06283D"

    screen5=Tk()
    screen5.geometry("1100x630+300+190")
    screen5.resizable(False,False)
    screen5.title("Feed the Need")
    screen5.configure(bg="#adacb1")


    def Upload():
        
        A11=Food_Name.get()
        A22=Quantity.get()
        A33=CookingDay.get()
        A44=Contact.get()
        A55=text_area.get(1.0,END)
        A66=text_area2.get(1.0,END)
        print(A11,A22,A33,A44,A55,A66)

        client=pymongo.MongoClient("mongodb://localhost:27017")
        db=client['LoginDatabase']
        collection=db['Donation']
        dic={'username':A1,
            'foodname':Food_Name.get(),
            'quantity':Quantity.get(),
            'cookingday' :CookingDay.get(),
            'phonenumber':Contact.get(),
            'location' :text_area.get(1.0, END),
            'description':text_area2.get(1.0,END)
            }
        collection.insert_one(dic)

        screen5.destroy()



        






            
    #icon
    image_icon=PhotoImage(file="Image/national.png")
    screen5.iconphoto(False,image_icon)

    #Header
    frame=Frame(screen5,width=1200,height=130,bg="#2e3192")
    frame.place(x=0,y=0)

    logo=PhotoImage(file="Image/national.png")
    mylogo=Label(frame,image=logo,background="#2e3192")
    mylogo.place(x=30,y=10)

    Label(frame,text='Feed the need',font=('arial',20,'bold'),fg='#fff',bg='#2e3192').place(x=130,y=60)

    #Doncation form
    obj=LabelFrame(screen5,text="Donation Form",font=20,bd=2,width=900,bg=framebg,fg=framefg,height=250,relief=GROOVE)
    obj.place(x=30,y=200)

    Label(obj,text="Food Name:",font="arial 13",bg=framebg,fg=framefg).place(x=30,y=50)
    Label(obj,text="Quantity:",font="arial 13",bg=framebg,fg=framefg).place(x=30,y=100)
    Label(obj,text="Cooking Day:",font="arial 13",bg=framebg,fg=framefg).place(x=30,y=150)

    Label(obj,text="Contact Number:",font="arial 13",bg=framebg,fg=framefg).place(x=500,y=50)
    Label(obj,text="Location:",font="arial 13",bg=framebg,fg=framefg).place(x=500,y=100)
    Label(obj,text="Description:",font="arial 13",bg=framebg,fg=framefg).place(x=500,y=150)

    Food_Name=StringVar()
    name_entry = Entry(obj,textvariable=Food_Name,width=20,font="arial 10")
    name_entry.place(x=160,y=50)

    Quantity=StringVar()
    quantity_entry = Entry(obj,textvariable=Quantity,width=20,font="arial 10")
    quantity_entry.place(x=160,y=100)

    CookingDay=StringVar()
    cooking_entry = Entry(obj,textvariable=CookingDay,width=20,font="arial 10")
    cooking_entry.place(x=160,y=150)




    Contact=StringVar()
    contact_entry = Entry(obj,textvariable=Contact,width=20,font="arial 10")
    contact_entry.place(x=630,y=50)

    text_area=Text(obj,font="Robote 14",bg="white",relief=GROOVE,wrap=WORD)
    text_area.place(x=630,y=96,width=240,height=50)

    text_area2=Text(obj,font="Robote 14",bg="white",relief=GROOVE,wrap=WORD)
    text_area2.place(x=630,y=150,width=240,height=50)


    Button(screen5,text="Upload",width=19,height=2,font="arial 12 bold",bg="lightblue",command=Upload).place(x=730,y=470)
    #################################################################
    #footer
    Bottom=Frame(screen5,width=1150,height=100,bg="#3cb878")
    Bottom.pack(side=BOTTOM)

    screen5.mainloop()


def receive():
    screen7=Tk()
    screen7.geometry("1100x630+300+190")
    screen7.resizable(False,False)
    screen7.title("Feed the need")
    screen7.configure(bg="#adacb1")
    global inc
    inc=0

    def receiver():
        global inc

    
        

        client=pymongo.MongoClient("mongodb://localhost:27017")
        db=client['LoginDatabase']
        collection=db['Donation']


        r=collection.find()
        print(r[inc]['foodname'])
        
        
        i=1
        while i<6:

            T1[f'a{i}'].config(text=r[inc]['foodname'])
            T2[f'b{i}'].config(text=r[inc]['quantity'])
            T3[f'c{i}'].config(text=r[inc]['cookingday'])
            T4[f'd{i}'].config(text=r[inc]['phonenumber'])
            T5[f'e{i}'].insert(END,r[inc]['location'])
            T6[f'f{i}'].insert(END,r[inc]['description'])
        
            i=i+1
            
            inc=inc+1
            


            
    #icon
    image_icon=PhotoImage(file="Image/national.png")
    screen7.iconphoto(False,image_icon)

    #Header
    frame=Frame(screen7,width=1200,height=130,bg="#2e3192")
    frame.place(x=0,y=0)

    logo=PhotoImage(file="Image/national.png")
    mylogo=Label(frame,image=logo,background="#2e3192")
    mylogo.place(x=30,y=10)

    Label(frame,text='Feed the need',font=('arial',20,'bold'),fg='#fff',bg='#2e3192').place(x=130,y=60)


    ##########################################################################
    recimage=PhotoImage(file="Image/Rectangle.png")

    ######################
    img1=Label(screen7,image=recimage,bg="#adacb1")
    img1.place(x=60,y=180)
    frame1=Frame(screen7,width=170,height=240,bg="white")
    frame1.place(x=70,y=190)
    Label(frame1,text="Food item:",bg="white").place(x=0,y=10)
    Label(frame1,text="Quantity:",bg="white").place(x=0,y=40)
    Label(frame1,text="Cooking Date:",bg="white").place(x=0,y=70)
    Label(frame1,text="Phone No.:",bg="white").place(x=0,y=100)
    Label(frame1,text="Location:",bg="white").place(x=0,y=140)
    Label(frame1,text="info:",bg="white").place(x=0,y=180)

    img2=Label(screen7,image=recimage,bg="#adacb1")
    img2.place(x=260,y=180)
    frame2=Frame(screen7,width=170,height=240,bg="white")
    frame2.place(x=270,y=190)
    Label(frame2,text="Food item:",bg="white").place(x=0,y=10)
    Label(frame2,text="Quantity:",bg="white").place(x=0,y=40)
    Label(frame2,text="Cooking Date:",bg="white").place(x=0,y=70)
    Label(frame2,text="Phone No.:",bg="white").place(x=0,y=100)
    Label(frame2,text="Location:",bg="white").place(x=0,y=140)
    Label(frame2,text="info:",bg="white").place(x=0,y=180)

    img3=Label(screen7,image=recimage,bg="#adacb1")
    img3.place(x=460,y=180)
    frame3=Frame(screen7,width=170,height=240,bg="white")
    frame3.place(x=470,y=190)
    Label(frame3,text="Food item:",bg="white").place(x=0,y=10)
    Label(frame3,text="Quantity:",bg="white").place(x=0,y=40)
    Label(frame3,text="Cooking Date:",bg="white").place(x=0,y=70)
    Label(frame3,text="Phone No.:",bg="white").place(x=0,y=100)
    Label(frame3,text="Location:",bg="white").place(x=0,y=140)
    Label(frame3,text="info:",bg="white").place(x=0,y=180)

    img4=Label(screen7,image=recimage,bg="#adacb1")
    img4.place(x=660,y=180)
    frame4=Frame(screen7,width=170,height=240,bg="white")
    frame4.place(x=670,y=190)
    Label(frame4,text="Food item:",bg="white").place(x=0,y=10)
    Label(frame4,text="Quantity:",bg="white").place(x=0,y=40)
    Label(frame4,text="Cooking Date:",bg="white").place(x=0,y=70)
    Label(frame4,text="Phone No.:",bg="white").place(x=0,y=100)
    Label(frame4,text="Location:",bg="white").place(x=0,y=140)
    Label(frame4,text="info:",bg="white").place(x=0,y=180)

    img5=Label(screen7,image=recimage,bg="#adacb1")
    img5.place(x=860,y=180)
    frame5=Frame(screen7,width=170,height=240,bg="white")
    frame5.place(x=870,y=190)
    Label(frame5,text="Food item:",bg="white").place(x=0,y=10)
    Label(frame5,text="Quantity:",bg="white").place(x=0,y=40)
    Label(frame5,text="Cooking Date:",bg="white").place(x=0,y=70)
    Label(frame5,text="Phone No.:",bg="white").place(x=0,y=100)
    Label(frame5,text="Location:",bg="white").place(x=0,y=140)
    Label(frame5,text="info:",bg="white").place(x=0,y=180)

    T1={'a1': Label(frame1,text="Movie name",font=("arial",10),fg="green"),'a2': Label(frame2,text="Movie name",font=("arial",10),fg="green"),'a3': Label(frame3,text="Movie name",font=("arial",10),fg="green"),'a4': Label(frame4,text="Movie name",font=("arial",10),fg="green"),'a5': Label(frame5,text="Movie name",font=("arial",10),fg="green")}
    T1['a1'].place(x=60,y=10)
    T1['a2'].place(x=60,y=10)
    T1['a3'].place(x=60,y=10)
    T1['a4'].place(x=60,y=10)
    T1['a5'].place(x=60,y=10)

    T2={'b1': Label(frame1,text="Movie name",font=("arial",10),fg="green"),'b2': Label(frame2,text="Movie name",font=("arial",10),fg="green"),'b3': Label(frame3,text="Movie name",font=("arial",10),fg="green"),'b4': Label(frame4,text="Movie name",font=("arial",10),fg="green"),'b5': Label(frame5,text="Movie name",font=("arial",10),fg="green")}
    T2['b1'].place(x=60,y=40)
    T2['b2'].place(x=60,y=40)
    T2['b3'].place(x=60,y=40)
    T2['b4'].place(x=60,y=40)
    T2['b5'].place(x=60,y=40)

    T3={'c1': Label(frame1,text="Movie name",font=("arial",10),fg="green"),'c2': Label(frame2,text="Movie name",font=("arial",10),fg="green"),'c3': Label(frame3,text="Movie name",font=("arial",10),fg="green"),'c4': Label(frame4,text="Movie name",font=("arial",10),fg="green"),'c5': Label(frame5,text="Movie name",font=("arial",10),fg="green")}
    T3['c1'].place(x=85,y=70)
    T3['c2'].place(x=85,y=70)
    T3['c3'].place(x=85,y=70)
    T3['c4'].place(x=85,y=70)
    T3['c5'].place(x=85,y=70)


    T4={'d1': Label(frame1,text="Movie name",font=("arial",10),fg="green"),'d2': Label(frame2,text="Movie name",font=("arial",10),fg="green"),'d3': Label(frame3,text="Movie name",font=("arial",10),fg="green"),'d4': Label(frame4,text="Movie name",font=("arial",10),fg="green"),'d5': Label(frame5,text="Movie name",font=("arial",10),fg="green")}
    T4['d1'].place(x=70,y=100)
    T4['d2'].place(x=70,y=100)
    T4['d3'].place(x=70,y=100)
    T4['d4'].place(x=70,y=100)
    T4['d5'].place(x=70,y=100)

    T5={'e1': Text(frame1,width=15,height=2),'e2': Text(frame2,width=15,height=2),'e3': Text(frame3,width=15,height=2),'e4': Text(frame4,width=15,height=2),'e5': Text(frame5,width=15,height=2)}
    T5['e1'].place(x=57,y=134)
    T5['e2'].place(x=57,y=134)
    T5['e3'].place(x=57,y=134)
    T5['e4'].place(x=57,y=134)
    T5['e5'].place(x=57,y=134)

    T6={'f1': Text(frame1,width=15,height=2),'f2': Text(frame2,width=15,height=2),'f3': Text(frame3,width=15,height=2),'f4': Text(frame4,width=15,height=2),'f5': Text(frame5,width=15,height=2)}
    T6['f1'].place(x=57,y=180)
    T6['f2'].place(x=57,y=180)
    T6['f3'].place(x=57,y=180)
    T6['f4'].place(x=57,y=180)
    T6['f5'].place(x=57,y=180)

  

    ##################################

    receiver()

    #################################################################
    #footer
    Bottom=Frame(screen7,width=1150,height=100,bg="#fff")
    Bottom.pack(side=BOTTOM)

    screen7.mainloop()



def Database(A1,B2,C3,D4,E5):

    def Donation():
        screen4.destroy()
        Donate(A1,B2,C3,D4,E5)
    
    def receiving():
        screen4.destroy()
        receive()

    screen4=Tk()
    screen4.geometry("1100x630+300+190")
    screen4.resizable(False,False)
    screen4.title("Feed the need")
    screen4.configure(bg="#adacb1")

    #icon
    image_icon=PhotoImage(file="Image/national.png")
    screen4.iconphoto(False,image_icon)

    #Header
    frame=Frame(screen4,width=1200,height=130,bg="#2e3192")
    frame.place(x=0,y=0)

    logo=PhotoImage(file="Image/national.png")
    mylogo=Label(frame,image=logo,background="#2e3192")
    mylogo.place(x=30,y=10)

    Label(frame,text='Feed the need',font=('arial',20,'bold'),fg='#fff',bg='#2e3192').place(x=130,y=60)


    
    image3=PhotoImage(file="Image/Layer8.png")
    img3=Label(screen4,image=image3,bg="#adacb1")
    img3.place(x=0,y=150)

    image1=PhotoImage(file='Image/donate.png')
    registration=Button(screen4,image=image1,command=Donation)
    registration.place(x=600,y=200)


    image2=PhotoImage(file='Image/receive.png')
    gallery=Button(screen4,image=image2,command=receiving)
    gallery.place(x=850,y=200)



    #################################################################
    #footer
    Bottom=Frame(screen4,width=1150,height=100,bg="#fff")
    Bottom.pack(side=BOTTOM)

    screen4.mainloop()


##############%%%%%%%%%%%

def login():
    root.destroy()
    screen2=Tk()
    screen2.geometry("1100x630+300+190")
    screen2.resizable(False,False)
    screen2.title("Feed the need")
    screen2.configure(bg="#adacb1")


    def signin():
        username=user.get()
        password=code.get()

        client=pymongo.MongoClient("mongodb://localhost:27017")
        db=client['LoginDatabase']
        collection=db['register']

        r=collection.find_one({ "username":user.get()})

        # print(r.keys())
        # print(r.values())

        A1=r['username']
        B2=r['password']
        C3=r['emailid']
        D4=r['phonenumber']
        E5=r['location']

        print(A1)
        print(B2)
        print(C3)
        print(D4)
        print(E5)

        
        if username==str(A1) and password==B2:
            messagebox.showinfo("info","Login Sucessfully")
            screen2.destroy()
            Database(A1,B2,C3,D4,E5)
            
            
            

        else:
            messagebox.showerror('Invalid','invalid username or password')

            
    #icon
    image_icon=PhotoImage(file="Image/national.png")
    screen2.iconphoto(False,image_icon)

    #Header
    frame=Frame(screen2,width=1200,height=130,bg="#2e3192")
    frame.place(x=0,y=0)

    logo=PhotoImage(file="Image/national.png")
    mylogo=Label(frame,image=logo,background="#2e3192")
    mylogo.place(x=30,y=10)

    Label(frame,text='Feed the need',font=('arial',20,'bold'),fg='#fff',bg='#2e3192').place(x=130,y=60)


    ##########################################################################
    image3=PhotoImage(file="Image/Layer8.png")
    img3=Label(screen2,image=image3,bg="#adacb1")
    img3.place(x=0,y=180)


    frame1=Frame(screen2,width=250,height=350,bg="white")
    frame1.place(x=700,y=160)

    heading=Label(frame1,text='Login to enter',fg='#57a1f8',bg='white',font='arial 15 ')
    heading.place(x=60,y=5)

    #########------------------------------------------------------

    def on_enter(e):
        user.delete(0, 'end')

    def on_leave(e):
        name=user.get()
        if name=='':
            user.insert(0,'Username')

        
    user = Entry(frame1,width=20,fg='black',border=0,bg="white",font=('Microsoft YaHei UI Light',11))
    user.place(x=30,y=80)
    user.insert(0,'Username')
    user.bind('<FocusIn>', on_enter)
    user.bind('<FocusOut>', on_leave)

    Frame(frame1,width=180,height=2,bg='black').place(x=25,y=100)

    ###########-----------------------------------------------------
    def on_enter(e):
        code.delete(0, 'end')

    def on_leave(e):
        name=code.get()
        if name=='':
            code.insert(0,'Password')



    code = Entry(frame1,width=20,fg='black',border=0,bg="white",font=('Microsoft YaHei UI Light',11))
    code.place(x=30,y=150)
    code.insert(0,'Password')
    code.bind('<FocusIn>', on_enter)
    code.bind('<FocusOut>', on_leave)

    Frame(frame1,width=180,height=2,bg='black').place(x=30,y=177)

    ###############################################################

    Button(frame1,width=25,pady=7,text='Login',bg='#57a1f8',fg='white',border=0,command=signin).place(x=27,y=204)
    #################################################################
    #footer
    Bottom=Frame(screen2,width=1150,height=100,bg="#fff")
    Bottom.pack(side=BOTTOM)

    screen2.mainloop()

###################################################################333333
def register():
    root.destroy()
   

    screen3=Tk()
    screen3.geometry("1100x630+300+190")
    screen3.resizable(False,False)
    screen3.title("Feed the need")
    screen3.configure(bg="#adacb1")


    def signup():
        username=user.get()
        password=code.get()
        emailid=email.get()
        phonenumber=contact.get()
        location=Address.get(1.0, END)

        print(username,password,emailid,phonenumber,location)

        client=pymongo.MongoClient("mongodb://localhost:27017")
        db=client['LoginDatabase']
        collection=db['register']
        dic={
            'username':user.get(),
            'password':code.get(),
            'emailid' :email.get(),
            'phonenumber':contact.get(),
            'location' :Address.get(1.0, END)}
        collection.insert_one(dic)



        






            
    #icon
    image_icon=PhotoImage(file="Image/national.png")
    screen3.iconphoto(False,image_icon)

    #Header
    frame=Frame(screen3,width=1200,height=130,bg="#2e3192")
    frame.place(x=0,y=0)

    logo=PhotoImage(file="Image/national.png")
    mylogo=Label(frame,image=logo,background="#2e3192")
    mylogo.place(x=30,y=10)

    Label(frame,text='Feed the need',font=('arial',20,'bold'),fg='#fff',bg='#2e3192').place(x=130,y=60)


    ##########################################################################
    image3=PhotoImage(file="Image/Layer8.png")
    img3=Label(screen3,image=image3,bg="#adacb1")
    img3.place(x=0,y=180)


    frame1=Frame(screen3,width=650,height=450,bg="#adacb1")
    frame1.place(x=400,y=160)


    #########------------------------------------------------------   
    Label(frame1,text="Username",font="arial 11",bg="#adacb1").place(x=30,y=50)
    user = Entry(frame1,width=20,fg='black',border=0,bg="white",font=('Microsoft YaHei UI Light',11))
    user.place(x=30,y=80)



    ###########-----------------------------------------------------
    Label(frame1,text="Password",font="arial 11",bg="#adacb1").place(x=30,y=120)
    code = Entry(frame1,width=20,fg='black',border=0,bg="white",font=('Microsoft YaHei UI Light',11))
    code.place(x=30,y=150)

    Label(frame1,text="Email Id:",font="arial 11",bg="#adacb1").place(x=300,y=20)
    email = Entry(frame1,width=30,fg='black',border=0,bg="white",font=('Microsoft YaHei UI Light',11))
    email.place(x=300,y=45)

    Label(frame1,text="Phone Number:",font="arial 11",bg="#adacb1").place(x=300,y=80)
    contact = Entry(frame1,width=30,fg='black',border=0,bg="white",font=('Microsoft YaHei UI Light',11))
    contact.place(x=300,y=105)


    Label(frame1,text="Address:",font="arial 11",bg="#adacb1").place(x=300,y=140)
    Address = Text(frame1,width=30,height=5,fg='black',border=0,bg="white",font=('Microsoft YaHei UI Light',11))
    Address.place(x=300,y=165)


    ###############################################################

    Button(frame1,width=25,pady=7,text='Register',bg='#57a1f8',fg='white',border=0,command=signup).place(x=150,y=304)
    #################################################################
    #footer
    Bottom=Frame(screen3,width=1150,height=100,bg="#3cb878")
    Bottom.pack(side=BOTTOM)

    screen3.mainloop()

########################################################################3



#icon
image_icon=PhotoImage(file="Image/national.png")
root.iconphoto(False,image_icon)

#Header
frame=Frame(root,width=1200,height=130,bg="#2e3192")
frame.place(x=0,y=0)

logo=PhotoImage(file="Image/national.png")
mylogo=Label(frame,image=logo,background="#2e3192")
mylogo.place(x=30,y=10)

Label(frame,text='Feed the need',font=('arial',20,'bold'),fg='#fff',bg='#2e3192').place(x=130,y=60)


##########################################################################
image3=PhotoImage(file="Image/Layer8.png")
img3=Label(root,image=image3,bg="#adacb1")
img3.place(x=0,y=150)

image1=PhotoImage(file='Image/image1.png')
registration1=Button(root,image=image1,command=login)
registration1.place(x=600,y=200)


image2=PhotoImage(file='Image/image2.png')
registration2=Button(root,image=image2,command=register)
registration2.place(x=850,y=200)








#################################################################
#footer
Bottom=Frame(root,width=1150,height=100,bg="#fff")
Bottom.pack(side=BOTTOM)

root.mainloop()
